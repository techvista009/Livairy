"use client";

import { useState, useMemo } from "react";
import Header from "@/components/Header";
import OpportunityCard from "@/components/OpportunityCard";
import { opportunities, categories } from "@/data/opportunities";
import Link from "next/link";

export default function DiscoverPage() {
  const [search, setSearch] = useState("");
  const [selectedCats, setSelectedCats] = useState<string[]>(["Internship"]);
  const [remoteOnly, setRemoteOnly] = useState(true);
  const [locationIndia, setLocationIndia] = useState(true);

  const filtered = useMemo(() => {
    return opportunities.filter((o) => {
      if (search) {
        const q = search.toLowerCase();
        if (
          !o.title.toLowerCase().includes(q) &&
          !o.organization.toLowerCase().includes(q) &&
          !o.tags.some((t) => t.toLowerCase().includes(q))
        )
          return false;
      }
      if (selectedCats.length && !selectedCats.includes(o.category)) return false;
      if (remoteOnly && !o.remote) return false;
      if (locationIndia && !o.location.toLowerCase().includes("india") && !o.remote) return false;
      return true;
    });
  }, [search, selectedCats, remoteOnly, locationIndia]);

  const toggleCat = (cat: string) => {
    setSelectedCats((prev) =>
      prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]
    );
  };

  return (
    <div className="min-h-screen">
      <Header variant="app" />

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold tracking-tight">Explore Opportunities</h1>
          <p className="mt-1 text-sm text-[var(--text-muted)]">
            Find the right opportunity to grow your skills, gain experience and build your future.
          </p>
        </div>

        {/* Search bar */}
        <div className="mb-6 flex items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-1.5">
          <svg className="ml-3 text-[var(--text-dim)]" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" />
          </svg>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search opportunities, skills, companies..."
            className="flex-1 bg-transparent py-2.5 text-sm outline-none placeholder:text-[var(--text-dim)]"
          />
          <button className="flex h-9 w-9 items-center justify-center rounded-lg bg-[var(--accent)] text-black">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" />
            </svg>
          </button>
        </div>

        <div className="flex flex-col gap-6 lg:flex-row">
          {/* Filters */}
          <aside className="w-full shrink-0 lg:w-56">
            <div className="card sticky top-20 p-4">
              <div className="mb-4 flex items-center justify-between">
                <span className="text-sm font-medium">Filters</span>
                <button
                  className="text-xs text-[var(--text-dim)] hover:text-white"
                  onClick={() => {
                    setSelectedCats([]);
                    setRemoteOnly(false);
                    setLocationIndia(false);
                  }}
                >
                  Clear all
                </button>
              </div>

              <div className="space-y-5">
                <div>
                  <div className="mb-2 text-xs font-medium uppercase tracking-wider text-[var(--text-dim)]">
                    Category
                  </div>
                  <div className="space-y-2">
                    {categories.map((c) => (
                      <label key={c.name} className="flex cursor-pointer items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={selectedCats.includes(c.name)}
                          onChange={() => toggleCat(c.name)}
                          className="h-3.5 w-3.5 rounded border-[var(--border)] bg-transparent accent-[var(--accent)]"
                        />
                        <span className={selectedCats.includes(c.name) ? "text-white" : "text-[var(--text-muted)]"}>
                          {c.name}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="mb-2 text-xs font-medium uppercase tracking-wider text-[var(--text-dim)]">
                    Location
                  </div>
                  <div className="space-y-2">
                    <label className="flex cursor-pointer items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={locationIndia}
                        onChange={(e) => setLocationIndia(e.target.checked)}
                        className="h-3.5 w-3.5 rounded accent-[var(--accent)]"
                      />
                      <span className={locationIndia ? "text-white" : "text-[var(--text-muted)]"}>India</span>
                    </label>
                    <label className="flex cursor-pointer items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={remoteOnly}
                        onChange={(e) => setRemoteOnly(e.target.checked)}
                        className="h-3.5 w-3.5 rounded accent-[var(--accent)]"
                      />
                      <span className={remoteOnly ? "text-white" : "text-[var(--text-muted)]"}>Remote</span>
                    </label>
                  </div>
                </div>

                <div>
                  <div className="mb-2 text-xs font-medium uppercase tracking-wider text-[var(--text-dim)]">
                    Experience Level
                  </div>
                  <div className="space-y-2">
                    {["Beginner", "Intermediate", "Advanced"].map((l) => (
                      <label key={l} className="flex cursor-pointer items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          defaultChecked={l === "Beginner"}
                          className="h-3.5 w-3.5 rounded accent-[var(--accent)]"
                        />
                        <span className="text-[var(--text-muted)]">{l}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* Results */}
          <div className="flex-1">
            <div className="mb-4 flex items-center justify-between">
              <span className="text-sm text-[var(--text-muted)]">
                {filtered.length.toLocaleString()} opportunities
              </span>
              <select className="rounded-lg border border-[var(--border)] bg-[var(--bg-card)] px-3 py-1.5 text-xs text-[var(--text-muted)] outline-none">
                <option>Sort by: Most recent</option>
                <option>Best match</option>
                <option>Deadline soon</option>
              </select>
            </div>

            <div className="grid gap-3 sm:grid-cols-1">
              {filtered.map((opp) => (
                <OpportunityCard key={opp.id} opp={opp} />
              ))}
              {filtered.length === 0 && (
                <div className="card flex flex-col items-center justify-center py-16 text-center">
                  <p className="text-[var(--text-muted)]">No opportunities match your filters.</p>
                  <button
                    className="mt-3 text-sm text-[var(--accent)] hover:underline"
                    onClick={() => {
                      setSelectedCats([]);
                      setRemoteOnly(false);
                      setLocationIndia(false);
                      setSearch("");
                    }}
                  >
                    Clear filters
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
