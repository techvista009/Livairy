import Link from "next/link";
import Header from "@/components/Header";
import OpportunityCard from "@/components/OpportunityCard";
import { opportunities, liveStats } from "@/data/opportunities";

export default function HomePage() {
  const liveFeed = opportunities.filter((o) => o.isNew).slice(0, 3);

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      {/* Hero */}
      <section className="relative overflow-hidden">
        {/* Earth-like background glow */}
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute bottom-0 left-1/2 h-[500px] w-[900px] -translate-x-1/2 rounded-full bg-[radial-gradient(ellipse_at_center,rgba(34,197,94,0.12)_0%,transparent_70%)]" />
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiMyMmM1NWUiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDM0djItaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-40" />
        </div>

        <div className="relative mx-auto grid max-w-7xl gap-10 px-4 pb-20 pt-16 sm:px-6 lg:grid-cols-2 lg:gap-12 lg:pt-24">
          {/* Left copy */}
          <div className="flex flex-col justify-center">
            <h1 className="text-4xl font-semibold leading-[1.15] tracking-tight sm:text-5xl lg:text-[3.25rem]">
              Find what&apos;s next.
              <br />
              <span className="text-[var(--accent)]">Before everyone else.</span>
            </h1>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-[var(--text-muted)]">
              Discover internships, scholarships, hackathons, grants, jobs and
              other opportunities matched to what you&apos;re looking for.
            </p>

            {/* Search */}
            <div className="mt-8 flex max-w-md items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--bg-card)] p-1.5 shadow-lg shadow-black/20">
              <svg className="ml-3 text-[var(--text-dim)]" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" />
              </svg>
              <input
                type="text"
                placeholder="Search opportunities, skills, companies..."
                className="flex-1 bg-transparent py-2.5 text-sm outline-none placeholder:text-[var(--text-dim)]"
              />
              <button className="flex h-9 w-9 items-center justify-center rounded-full bg-[var(--accent)] text-black">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" />
                </svg>
              </button>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/discover" className="btn-primary">
                Explore Opportunities →
              </Link>
              <Link href="/for-organizations" className="btn-secondary">
                I&apos;m an Organization
              </Link>
            </div>

            {/* Stats */}
            <div className="mt-12 grid grid-cols-2 gap-6 sm:grid-cols-4">
              {[
                { value: liveStats.opportunities, label: "Opportunities" },
                { value: liveStats.organizations, label: "Organizations" },
                { value: liveStats.activeUsers, label: "Active Users" },
                { value: liveStats.countries, label: "Countries" },
              ].map((s) => (
                <div key={s.label}>
                  <div className="text-xl font-semibold text-white sm:text-2xl">{s.value}</div>
                  <div className="text-xs text-[var(--text-dim)]">{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Live feed */}
          <div className="flex flex-col">
            <div className="glass rounded-2xl p-5 shadow-2xl shadow-black/40">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-[var(--accent)]">
                  <span className="live-dot" />
                  LIVE OPPORTUNITY FEED
                </div>
                <Link href="/discover" className="text-xs text-[var(--text-muted)] hover:text-white">
                  View all →
                </Link>
              </div>

              <div className="flex flex-col gap-3">
                {liveFeed.map((opp) => (
                  <div
                    key={opp.id}
                    className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg)]/60 p-3.5 transition hover:border-[var(--border)]"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-[var(--bg-elevated)] text-xs font-bold text-[var(--accent)]">
                          {opp.organization.charAt(0)}
                        </div>
                        <div>
                          <div className="text-sm font-medium">{opp.title}</div>
                          <div className="text-xs text-[var(--text-muted)]">{opp.organization}</div>
                        </div>
                      </div>
                      <span className="badge-new">NEW</span>
                    </div>
                    <div className="mt-2 flex items-center justify-between text-xs text-[var(--text-dim)]">
                      <span>{opp.location}</span>
                      <span className="text-[var(--amber)]">Deadline in {opp.daysLeft} days</span>
                    </div>
                    <Link
                      href={`/opportunity/${opp.slug}`}
                      className="mt-2.5 inline-block text-xs font-medium text-[var(--accent)] hover:underline"
                    >
                      View opportunity →
                    </Link>
                  </div>
                ))}
              </div>
            </div>

            {/* Demo data notice */}
            <p className="mt-3 text-center text-[10px] uppercase tracking-widest text-[var(--text-dim)]">
              ● DEMO DATA — Sample opportunities for preview
            </p>
          </div>
        </div>
      </section>

      {/* Featured section */}
      <section className="border-t border-[var(--border)] bg-[var(--bg-elevated)]/50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="mb-8 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-semibold tracking-tight">Trending opportunities</h2>
              <p className="mt-1 text-sm text-[var(--text-muted)]">
                Recently discovered and highly matched
              </p>
            </div>
            <Link href="/discover" className="text-sm text-[var(--accent)] hover:underline">
              View all →
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {opportunities.slice(0, 6).map((opp) => (
              <OpportunityCard key={opp.id} opp={opp} />
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-[var(--border)] py-10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 text-sm text-[var(--text-dim)] sm:flex-row sm:px-6">
          <div className="flex items-center gap-2">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[var(--accent)] text-[10px] font-bold text-black">
              ●
            </span>
            <span>OPPORTUNITY LIVE</span>
          </div>
          <div className="flex flex-wrap justify-center gap-6">
            <Link href="/about" className="hover:text-white">About</Link>
            <Link href="/how-it-works" className="hover:text-white">How it works</Link>
            <Link href="/privacy" className="hover:text-white">Privacy</Link>
            <Link href="/terms" className="hover:text-white">Terms</Link>
            <Link href="/contact" className="hover:text-white">Contact</Link>
          </div>
          <p className="text-xs">© 2026 Opportunity Live. Discovery platform.</p>
        </div>
      </footer>
    </div>
  );
}
