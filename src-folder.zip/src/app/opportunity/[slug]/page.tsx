import Link from "next/link";
import { notFound } from "next/navigation";
import Header from "@/components/Header";
import { opportunities } from "@/data/opportunities";

export function generateStaticParams() {
  return opportunities.map((o) => ({ slug: o.slug }));
}

export default async function OpportunityPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const opp = opportunities.find((o) => o.slug === slug);
  if (!opp) notFound();

  return (
    <div className="min-h-screen">
      <Header variant="app" />

      <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
        <Link
          href="/discover"
          className="mb-6 inline-flex items-center gap-1.5 text-sm text-[var(--text-muted)] hover:text-white"
        >
          ← Back to results
        </Link>

        <div className="grid gap-8 lg:grid-cols-[1fr_280px]">
          <div>
            <div className="mb-2 flex flex-wrap items-center gap-2">
              {opp.verified && (
                <span className="badge-verified">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                  Verified source
                </span>
              )}
              {opp.isNew && <span className="badge-new">NEW</span>}
            </div>

            <h1 className="text-3xl font-semibold tracking-tight">{opp.title}</h1>
            <p className="mt-1 text-sm text-[var(--text-muted)]">
              Provided by{" "}
              <span className="text-[var(--accent)]">{opp.organization}</span>
              {" · "}
              <a href={opp.sourceUrl} target="_blank" rel="noopener" className="hover:underline">
                Source: official website ↗
              </a>
            </p>

            <div className="mt-4 flex flex-wrap gap-3 text-xs text-[var(--text-dim)]">
              <span className="flex items-center gap-1 rounded-full border border-[var(--border)] px-2.5 py-1">
                📍 {opp.location}
              </span>
              <span className="flex items-center gap-1 rounded-full border border-[var(--border)] px-2.5 py-1">
                {opp.category}
              </span>
            </div>

            <div className="mt-8 space-y-8">
              <section>
                <h2 className="mb-3 text-lg font-medium">About this opportunity</h2>
                <div className="whitespace-pre-line text-sm leading-relaxed text-[var(--text-muted)]">
                  {opp.description}
                </div>
              </section>

              <section>
                <h2 className="mb-3 text-lg font-medium">Eligibility</h2>
                <ul className="space-y-2">
                  {opp.eligibility.map((e) => (
                    <li key={e} className="flex items-start gap-2 text-sm text-[var(--text-muted)]">
                      <span className="mt-0.5 text-[var(--accent)]">✓</span>
                      {e}
                    </li>
                  ))}
                </ul>
              </section>

              <section>
                <h2 className="mb-3 text-lg font-medium">What you&apos;ll need</h2>
                <div className="flex flex-wrap gap-2">
                  {opp.requirements.map((r) => (
                    <span
                      key={r}
                      className="rounded-full border border-[var(--border)] bg-[var(--bg-card)] px-3 py-1 text-xs"
                    >
                      {r}
                    </span>
                  ))}
                </div>
              </section>

              <section>
                <h2 className="mb-3 text-lg font-medium">Benefits</h2>
                <ul className="space-y-2">
                  {opp.benefits.map((b) => (
                    <li key={b} className="flex items-start gap-2 text-sm text-[var(--text-muted)]">
                      <span className="mt-0.5 text-[var(--accent)]">✓</span>
                      {b}
                    </li>
                  ))}
                </ul>
              </section>
            </div>

            <p className="mt-10 text-xs text-[var(--text-dim)]">
              This opportunity is listed for informational purposes. OPPORTUNITY LIVE is not the organizer
              and does not guarantee selection, eligibility or authenticity. Always verify details on the
              official source before applying.
            </p>
          </div>

          <aside className="space-y-4">
            <div className="card p-5">
              <div className="text-center">
                <div className="text-2xl font-semibold text-[var(--amber)]">
                  {opp.daysLeft} days left
                </div>
                <div className="text-xs text-[var(--text-dim)]">Application deadline</div>
              </div>
              <a
                href={opp.applicationUrl}
                target="_blank"
                rel="noopener"
                className="btn-primary mt-4 w-full justify-center"
              >
                Apply Now
              </a>
              <button className="btn-secondary mt-2 w-full justify-center text-sm">
                ★ Save
              </button>
            </div>

            <div className="card p-5">
              <h3 className="mb-3 text-sm font-medium">Source Transparency</h3>
              <div className="space-y-3 text-xs text-[var(--text-muted)]">
                <div>
                  <div className="text-[var(--text-dim)]">Provided by</div>
                  <div className="font-medium text-white">{opp.organization}</div>
                </div>
                <div>
                  <div className="text-[var(--text-dim)]">Official source</div>
                  <a href={opp.sourceUrl} target="_blank" rel="noopener" className="text-[var(--accent)] hover:underline break-all">
                    {opp.sourceUrl.replace("https://", "")}
                  </a>
                </div>
                <div>
                  <div className="text-[var(--text-dim)]">Last checked</div>
                  <div className="font-medium text-white">{opp.lastVerified}</div>
                </div>
              </div>
            </div>

            {opp.match && (
              <div className="card p-5">
                <div className="mb-1 text-2xl font-semibold text-[var(--accent)]">{opp.match}% MATCH</div>
                <p className="text-xs text-[var(--text-dim)]">Based on your preferences</p>
              </div>
            )}
          </aside>
        </div>
      </div>
    </div>
  );
}
